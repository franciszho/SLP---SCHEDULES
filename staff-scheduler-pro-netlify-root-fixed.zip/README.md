# Staff Scheduler Pro

Fresh Netlify project with shared online saving.

## Deploy
1. Create a new GitHub repository.
2. Upload all files and folders from this project.
3. In Netlify choose Add new project > Import an existing project.
4. Select the repository and deploy with the detected settings.
5. Test `/api/schedule`; it should return JSON with `ok: true`.

The app uses Netlify Functions and Netlify Blobs. It also keeps a local browser copy as an offline fallback.
